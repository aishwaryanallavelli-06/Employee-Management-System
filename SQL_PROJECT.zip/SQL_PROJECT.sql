CREATE DATABASE EMS_DB;
USE EMS_DB;

-- Table 1: Job Department
CREATE TABLE JobDepartment (
    Job_ID INT PRIMARY KEY,
    jobdept VARCHAR(50),
    name VARCHAR(100),
    description TEXT,
    salaryrange VARCHAR(50)
);
-- Table 2: Salary/Bonus
CREATE TABLE SalaryBonus (
    salary_ID INT PRIMARY KEY,
    Job_ID INT,
    amount DECIMAL(10,2),
    annual DECIMAL(10,2),
    bonus DECIMAL(10,2),
    CONSTRAINT fk_salary_job FOREIGN KEY (job_ID) REFERENCES JobDepartment(Job_ID)
        ON DELETE CASCADE ON UPDATE CASCADE
);
-- Table 3: Employee
CREATE TABLE Employee (
    emp_ID INT PRIMARY KEY,
    firstname VARCHAR(50),
    lastname VARCHAR(50),
    gender VARCHAR(10),
    age INT,
    contact_add VARCHAR(100),
    emp_email VARCHAR(100) UNIQUE,
    emp_pass VARCHAR(50),
    Job_ID INT,
    CONSTRAINT fk_employee_job FOREIGN KEY (Job_ID)
        REFERENCES JobDepartment(Job_ID)
        ON DELETE SET NULL
        ON UPDATE CASCADE
);

-- Table 4: Qualification
CREATE TABLE Qualification (
    QualID INT PRIMARY KEY,
    Emp_ID INT,
    Position VARCHAR(50),
    Requirements VARCHAR(255),
    Date_In DATE,
    CONSTRAINT fk_qualification_emp FOREIGN KEY (Emp_ID)
        REFERENCES Employee(emp_ID)
        ON DELETE CASCADE
        ON UPDATE CASCADE
);

-- Table 5: Leaves
CREATE TABLE Leaves (
    leave_ID INT PRIMARY KEY,
    emp_ID INT,
    date DATE,
    reason TEXT,
    CONSTRAINT fk_leave_emp FOREIGN KEY (emp_ID) REFERENCES Employee(emp_ID)
        ON DELETE CASCADE ON UPDATE CASCADE
);

-- Table 6: Payroll
CREATE TABLE Payroll (
    payroll_ID INT PRIMARY KEY,
    emp_ID INT,
    job_ID INT,
    salary_ID INT,
    leave_ID INT,
    date DATE,
    report TEXT,
    total_amount DECIMAL(10,2),
    CONSTRAINT fk_payroll_emp FOREIGN KEY (emp_ID) REFERENCES Employee(emp_ID)
        ON DELETE CASCADE ON UPDATE CASCADE,
    CONSTRAINT fk_payroll_job FOREIGN KEY (job_ID) REFERENCES JobDepartment(job_ID)
        ON DELETE CASCADE ON UPDATE CASCADE,
    CONSTRAINT fk_payroll_salary FOREIGN KEY (salary_ID) REFERENCES SalaryBonus(salary_ID)
        ON DELETE CASCADE ON UPDATE CASCADE,
    CONSTRAINT fk_payroll_leave FOREIGN KEY (leave_ID) REFERENCES Leaves(leave_ID)
        ON DELETE SET NULL ON UPDATE CASCADE

);
SELECT  * FROM EMPLOYEE;
SELECT  * FROM JOBDEPARTMENT;
SELECT  * FROM SALARYBONUS;
SELECT  * FROM QUALIFICATION;
SELECT  * FROM LEAVES;
SELECT  * FROM PAYROLL;

-- 1. EMPLOYEE INSIGHTS
-- ● How many unique employees are currently in the system?
SELECT COUNT(DISTINCT Emp_ID) AS Total_Employees
FROM Employee;

-- ● Which departments have the highest number of employees? 
SELECT 
    JD.JobDept,
    COUNT(E.Emp_ID) AS Employee_Count
FROM Employee E
JOIN JobDepartment JD
    ON E.Job_ID = JD.Job_ID
GROUP BY JD.JobDept
ORDER BY Employee_Count DESC;


-- ● What is the average salary per department? 
SELECT 
    JD.JobDept,
    AVG(SB.Amount) AS Avg_Salary
FROM JobDepartment JD
JOIN SalaryBonus SB
    ON JD.Job_ID = SB.Job_ID
GROUP BY JD.JobDept
ORDER BY Avg_Salary DESC;

-- ● Who are the top 5 highest-paid employees?
SELECT
    E.emp_ID,
    CONCAT(E.firstname,' ',E.lastname) AS Employee_Name,
    J.jobdept,
    S.amount AS Salary
FROM Employee E
JOIN SalaryBonus S
    ON E.Job_ID = S.Job_ID
JOIN JobDepartment J
    ON E.Job_ID = J.Job_ID
ORDER BY S.amount DESC
LIMIT 5;

-- ● What is the total salary expenditure across the company?
SELECT SUM(S.amount) AS Total_Salary_Expenditure
FROM Employee E
JOIN SalaryBonus S
ON E.Job_ID = S.Job_ID;


-- 2. JOB ROLE AND DEPARTMENT ANALYSIS
-- ●How many different job roles exist in each department?
-- How many different job roles exist in each department?
SELECT
    jobdept,
    COUNT(DISTINCT name) AS total_job_roles
FROM JobDepartment
GROUP BY jobdept;

-- ● What is the average salary range per department?
SELECT
    J.jobdept,
    ROUND(AVG(S.amount),2) AS avg_salary
FROM JobDepartment J
JOIN SalaryBonus S
ON J.Job_ID = S.Job_ID
GROUP BY J.jobdept
ORDER BY avg_salary DESC;

-- ● Which job roles offer the highest salary?
SELECT
    J.name AS job_role,
    S.amount
FROM JobDepartment J
JOIN SalaryBonus S
ON J.Job_ID = S.Job_ID
ORDER BY S.amount DESC;

-- ● Which departments have the highest total salary allocation?
SELECT
    J.jobdept,
    SUM(S.amount) AS total_salary_allocation
FROM JobDepartment J
JOIN SalaryBonus S
ON J.Job_ID = S.Job_ID
GROUP BY J.jobdept
ORDER BY total_salary_allocation DESC;


-- 3. QUALIFICATION AND SKILLS ANALYSIS
-- ● How many employees have at least one qualification listed? 
SELECT
    COUNT(DISTINCT Emp_ID) AS qualified_employees
FROM Qualification;

-- ● Which positions require the most qualifications? 
SELECT
    Position,
    COUNT(*) AS qualification_count
FROM Qualification
GROUP BY Position
ORDER BY qualification_count DESC;

-- ● Which employees have the highest number of qualifications?
SELECT
    E.emp_ID,
    CONCAT(E.firstname,' ',E.lastname) AS employee_name,
    COUNT(Q.QualID) AS total_qualifications
FROM Employee E
JOIN Qualification Q
ON E.emp_ID = Q.Emp_ID
GROUP BY E.emp_ID, employee_name
ORDER BY total_qualifications DESC;


-- 4. LEAVE AND ABSENCE PATTERNS
-- ●Which year had the most employees taking leaves? 
SELECT
    YEAR(date) AS leave_year,
    COUNT(DISTINCT emp_ID) AS employees_on_leave
FROM Leaves
GROUP BY YEAR(date)
ORDER BY employees_on_leave DESC;

-- ● What is the average number of leave days taken by its employees per department?
SELECT
    J.jobdept,
    ROUND(COUNT(L.leave_ID) * 1.0 /
          COUNT(DISTINCT E.emp_ID),2) AS avg_leave_days
FROM Employee E
JOIN JobDepartment J
ON E.Job_ID = J.Job_ID
JOIN Leaves L
ON E.emp_ID = L.emp_ID
GROUP BY J.jobdept;

-- ● Which employees have taken the most leaves?
SELECT
    E.emp_ID,
    CONCAT(E.firstname,' ',E.lastname) AS employee_name,
    COUNT(L.leave_ID) AS total_leaves
FROM Employee E
JOIN Leaves L
ON E.emp_ID = L.emp_ID
GROUP BY E.emp_ID, employee_name
ORDER BY total_leaves DESC;

-- ● What is the total number of leave days taken company-wide? 
SELECT
    COUNT(*) AS total_leave_days
FROM Leaves;
-- ● How do leave days correlate with payroll amounts?
SELECT
    E.emp_ID,
    CONCAT(E.firstname,' ',E.lastname) AS employee_name,
    COUNT(L.leave_ID) AS leave_days,
    AVG(P.total_amount) AS avg_payroll
FROM Employee E
JOIN Leaves L
ON E.emp_ID = L.emp_ID
JOIN Payroll P
ON E.emp_ID = P.emp_ID
GROUP BY E.emp_ID, employee_name
ORDER BY leave_days DESC;

-- 5. PAYROLL AND COMPENSATION ANALYSIS
-- ●What is the total monthly payroll processed?
SELECT
    YEAR(date) AS year,
    MONTH(date) AS month,
    SUM(total_amount) AS total_monthly_payroll
FROM Payroll
GROUP BY YEAR(date), MONTH(date)
ORDER BY year, month;
 
-- ● What is the average bonus given per department? 
SELECT
    J.jobdept,
    ROUND(AVG(S.bonus),2) AS avg_bonus
FROM JobDepartment J
JOIN SalaryBonus S
ON J.Job_ID = S.Job_ID
GROUP BY J.jobdept
ORDER BY avg_bonus DESC;

-- doubt● Which department receives the highest total bonuses? 
SELECT
    J.jobdept,
    SUM(S.bonus) AS total_bonus
FROM JobDepartment J
JOIN SalaryBonus S
ON J.Job_ID = S.Job_ID
GROUP BY J.jobdept
ORDER BY total_bonus DESC;

-- ● What is the average value of total_amount after considering leave deductions?
SELECT
    ROUND(AVG(total_amount),2) AS avg_net_payment
FROM Payroll;


-- Challenges
-- ● Defining correct table relationships and ensuring accurate use of foreign keys.
-- ● Maintaining data consistency with cascading updates and deletes.
-- ● Writing complex joins for reports involving employee roles, leaves, and payroll.
-- ● Ensuring all date fields follow the YYYY-MM-DD format for reliable time-based analysis.
-- ● Preventing duplicate entries using unique constraints, especially on email fields.



